# Vinted Like Bot

Ein Discord-Bot zum Tauschen von Likes auf Vinted.

## Start
```bash
npm install
npm start
```